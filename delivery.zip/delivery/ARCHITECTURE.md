# MPQR Patta OTP — Architecture, Files & Implementation

A lean, **stateless** microservice that fetches Tamil Nadu land records
(**Patta / Chitta / FMB**) from the government portal (`eservices.tn.gov.in`),
gated by the customer's mobile **OTP**, and returns the document as a **base64
PDF**. Built for the MyPropertyQR app to consume over REST.

- **No** session pool, **no** database, **no** object storage, **no** persistence.
- Each request is self-contained: `send OTP → verify → fetch → PDF`.
- The customer's OTP is auto-read on **their** device (the MyPropertyQR app) and
  POSTed back — the service never handles SIMs or numbers.
- Runs headless Chromium (Playwright) from an **Indian IP** (Fly.io, Mumbai) —
  the government firewalls non-IN IPs.

> **Why a browser at all?** The TN government portal rejects direct HTTP/API calls
> (axios, curl, and even Playwright's out-of-page request context all get
> `INVALID ACCESS` — it fingerprints the TLS/session). The **only** thing it
> accepts is a request made **inside a real browser page** (the same context its
> own JavaScript uses). So every government call — dropdowns, OTP, chitta — runs
> through a headless Chromium session. This is a hard constraint of their portal,
> not a design preference.

---

## 1. The REST API (what the app calls)

All `/api/*` routes require the header **`X-API-Key: <MPQR_API_KEY>`**.
`/health` is open.

### `POST /api/patta/start` — send the OTP
```jsonc
{
  "mobileNo": "8940352877",
  // Prefer CODES (the app already has them from the dropdowns) — this SKIPS the
  // name→code resolution and is the fast path:
  "districtCode": "17", "talukCode": "01", "villageCode": "092", "nflag": "Y",
  // ...or send NAMES and the service resolves them live (slower on a cold cache):
  "districtName": "Ariyalur", "talukName": "Ariyalur", "villageName": "Alagiyamanavalam",
  "surveyNumber": "489/1B",       // "489/1B" → survey 489, sub-div 1B (auto-split)
  "subDivisionNumber": "1B",
  "landType": "R",                 // R = Rural, N = Natham
  "typeOfDocument": "Patta",
  "memberId": "…"                  // echoed back
}
```
→ `{ "status": true, "referenceId": "<machine.id>", "ttlSeconds": 300, "memberId": "…" }`

### `POST /api/patta/verify` — submit OTP, get the PDF
```jsonc
{ "referenceId": "…", "otp": "123456" }
```
→ `{ "status": true, "data": "<base64 PDF>", "referenceId": "…" }`
The PDF is the **government's own rendered patta** + the **FMB sketch**, merged.
**No branding / cover page** (customers print it as an official record).
On a merge failure it degrades to the government PDF alone (`"degraded": true`)
rather than losing the OTP.

### `POST /api/patta/resend` — resend OTP on a reference
`{ "referenceId": "…" }`

### `GET /api/live/{districts,taluks,villages,subdivs}` — live government pickers
The app populates its own location dropdowns from these (cached; ~0.5s):
```
GET /api/live/districts                                          → [{code,name,tamil}]         (38)
GET /api/live/taluks?district=08                                 → [{code,name,tamil,nflag}]
GET /api/live/villages?district=08&taluk=07                      → [{code,name,tamil}]
GET /api/live/subdivs?district=17&taluk=01&village=092&survey=1&nflag=Y&landtype=R → ["1A","1B1",…]
```

### `GET /health` (open) · `GET /metrics` (Prometheus, key-gated)
`/health` is always 200 with a `degraded` field (liveness). `/metrics` exposes
per-stage latency, warm-pool depth, and `mpqr_otp_wasted_total` (the money event).

### Error codes (stable, machine-readable)
| `code` | HTTP | Meaning / app action |
|---|---|---|
| `INVALID_INPUT` | 400 | Bad mobile/survey/subdiv/field. |
| `WRONG_OTP` | 400 | OTP rejected — re-enter (session stays alive for a retry). |
| `SESSION_EXPIRED` | 400 | Govt page idled out — start again (fresh OTP). |
| `VERIFY_EXPIRED` | 400 | Reference no longer held — start again. |
| `CHITTA_UNAVAILABLE` | 422 | OTP fine, no patta for this parcel (try other Land Type). |
| `RATE_LIMITED` | 429 | Daily OTP limit for this mobile (10/day). Back off. |
| `OTP_SEND_FAILED` | 502 | Govt didn't send the OTP. Retryable. |
| `GOVT_DOWN` / `GOVT_TIMEOUT` | 503/504 | Portal down / timed out. Retry shortly. |
| `SHEDDING` | 503 | Instance draining / memory-pressured. Retry shortly. |

`referenceId` is `"<machineId>.<id>"`; a `/verify` that lands on the wrong machine
(multi-machine deploy) is transparently `fly-replay`'d to the owner. A retried
`/verify` with the same `referenceId`+`otp` returns the **same** result — it never
re-spends the OTP.

---

## 2. Typical app integration flow

1. **Location pickers** — the app calls `/api/live/*` to fill District → Taluk →
   Village dropdowns, and `/api/live/subdivs` once a survey number is entered.
   (Pre-fetch districts at app launch to warm the cache.)
2. **Start** — the app POSTs `/api/patta/start` with the selected **codes** +
   mobile → gets a `referenceId`.
3. **Auto-read OTP** — the app reads the incoming SMS (see `otp-reader-android/`)
   and POSTs `/api/patta/verify { referenceId, otp }`.
4. **PDF** — the app receives the base64 PDF (patta + FMB) and shows/saves it.

Government limit: **10 OTPs/day/mobile**. Since each customer uses their own
mobile, that's per-customer, not a system bottleneck.

---

## 3. File-by-file

### Service entry
| File | Purpose |
|---|---|
| `bot/server.js` | The Express REST API — all routes above, API-key auth, name→code resolution, circuit breaker + idempotency wrappers, base64 PDF response, structured logging, `/metrics`, deep `/health`, drain-correct shutdown, crash guards. The only process started in production (`node bot/server.js`). |

### Core OTP automation (`lib/`)
| File | Purpose |
|---|---|
| `lib/index.js` | Public entry point — inits the OTP service; exposes `beginVerification` / `completeVerification` / `resendOtp` / `stats` / `shutdown`. |
| `lib/otp-service.js` | OTP orchestration + the **warm-browser pool**. `beginVerification` sends the OTP (grabbing a pre-warmed browser, refreshing it from the govt home page if stale); `completeVerification` submits the OTP, captures the chitta, closes its browser, and refills the pool. Input validation, metrics, typed errors. |
| `lib/playwright-session.js` | One headless Chromium session driving the TN form: navigate + mint access tokens (`_openForm`), `refreshSession` (re-navigate fresh from home), `govtAjax` (in-page fetch — the accepted way to call govt endpoints), `sendOtp`, `submitOtp` (verify → submit → capture the govt's **own** page as a PDF), dialog handling. |
| `lib/browser-launcher.js` | Concurrency-limited, hardened Chromium launcher (semaphore + `--disable-dev-shm-usage` etc.; disconnect-release so a crash can't wedge the queue). |
| `lib/pdf-generator.js` | Builds the final PDF with `pdf-lib`: the government's chitta PDF + the FMB sketch (fetched in parallel), merged. **No branded front page** (env-gated off). |
| `lib/fmb-extractor.js` | Pulls the FMB (field-map) sketch URL out of the chitta HTML. |
| `lib/tns-client.js` | Legacy HTTP client for the govt endpoints (retained; not on the live path — the govt blocks external HTTP). |

### Government data resolution (`bridge/`)
| File | Purpose |
|---|---|
| `bridge/tns-live.js` | Live government dropdowns via a dedicated **data-browser** (in-page fetch), with an in-memory **cache** (districts 6h, taluks/villages 1h). Backs `/api/live/*` and name→code resolution. |
| `bridge/mpqr-resolver.js` | CSV-based district/taluk/village name→code fallback (used only if the live feed is unreachable). |

### Resilience, observability & errors (`lib/`)
| File | Purpose |
|---|---|
| `lib/errors.js` | Typed error taxonomy (`AppError` = `code` + `httpStatus` + `retryable`) + `classify()`. |
| `lib/govt-breaker.js` | Circuit breaker (opossum) around govt calls — a portal outage fast-fails `GOVT_DOWN`; business errors never trip it. |
| `lib/verify-idempotency.js` | In-memory `(referenceId, otp)` cache so a retried `/verify` never re-spends the OTP. |
| `lib/mem-watchdog.js` | RSS-ceiling watchdog: sheds new `/start` under memory pressure, restarts cleanly before OOM. |
| `lib/http-agent.js` | Shared keep-alive HTTPS agents (used only by the FMB fetch; the govt path uses the browser). |
| `lib/logger.js` | Structured JSON logging (pino) → stdout, with mobile/OTP/API-key redaction. |
| `lib/metrics.js` | Prometheus metrics (prom-client), served at `/metrics`. |

### Data / UI / mobile
| Path | Purpose |
|---|---|
| `data/tn-districts.csv` | Small district/taluk/village name↔code sample (resolver fallback). |
| `public/dashboard.html` | **Test harness only** — an API tester (served at `/dashboard`). NOT part of the product; the app calls the REST API directly. |
| `public/index.html` | Redirect/landing helper. |
| `otp-reader-android/OtpAutoReader.kt` | Android SMS auto-reader for the app — silent `RECEIVE_SMS` receiver filtered to the fixed TN govt sender; hands the OTP to a callback. |
| `otp-reader-android/README.md` | Wiring + the Google-Play caveat + the SMS-User-Consent fallback. |

### Config & build
| File | Purpose |
|---|---|
| `Dockerfile` | Playwright + Node 22 image; runs `node bot/server.js`. |
| `fly.toml` | Fly.io deploy config (Mumbai `bom`, health check, env). API key is a Fly **secret**, not here. |
| `package.json` / `package-lock.json` | Dependencies + scripts (`start`, `dev`). |
| `.env.example` | Config template (copy to `.env` for local dev). |
| `.gitignore` / `.dockerignore` | Ignore rules. |
| `GOVERNMENT_ENDPOINTS.md` | Reference of the raw TN government endpoints. |
| `README.md` | Short service README. |

---

## 4. Configuration (environment variables)

| Var | Default | Notes |
|---|---|---|
| `MPQR_API_KEY` | `dev-key-change-me` | **Required** in `X-API-Key`. Set in prod via `fly secrets set`. |
| `PORT` | `3030` | |
| `PLAYWRIGHT_HEADLESS` | `true` | |
| `PLAYWRIGHT_TIMEOUT_MS` | `30000` | Per-step Playwright timeout. |
| `MPQR_MAX_CONCURRENT_BROWSERS` | `6` | Hard cap on simultaneous headless browsers (the memory guard, ~300 MB each). |
| `MPQR_WARM_POOL_SIZE` | `3` | Pre-launched browsers parked at the govt form → fast OTP send. |
| `MPQR_WARM_FRESH_MS` | `60000` | A warm browser older than this is re-navigated from home before a send. |
| `MPQR_KEEPALIVE_MS` | `0` (**disabled**) | Session keep-alive ping. **Off** — it corrupted the live OTP session; left off until a safe idle-refresh is proven. |
| `MPQR_RSS_CEILING_MB` | `1500` | Memory watchdog ceiling (keep under the VM's RAM). |
| `LOG_LEVEL` | `info` | pino level. |
| `PDF_FRONT_PAGE` | `off` | Branded cover page — off (deliver patta + FMB only). |

---

## 5. Notes / current state

- **Keep-alive is OFF** (`MPQR_KEEPALIVE_MS=0`). It was an attempt to stop the govt
  session idling out, but its in-page ping corrupted the live OTP session (the govt
  rejected correct OTPs). Instead, a warm browser is **re-navigated fresh from the
  govt home page** if it's stale before a send. Do not re-enable keep-alive without
  re-validating against a real OTP.
- **Request interception is OFF** by default (`MPQR_BLOCK_TRACKERS` unset) for the
  same "don't touch the live session" reason.
- The service is stateless; horizontal scaling is safe. `referenceId` carries the
  machine id only for `fly-replay` routing, not persistence.
