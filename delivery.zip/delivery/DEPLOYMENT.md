# MPQR Patta OTP — Deployment Guide

How and where the service is deployed, and how to deploy it on your own platform.

---

## 0. The one hard requirement: an INDIAN IP

The TN government portal (`eservices.tn.gov.in`) **firewalls all non-Indian IPs**.
The service **must** run from an Indian datacenter/residential IP. Anywhere with an
Indian egress IP works (Fly.io Mumbai, AWS `ap-south-1`, GCP `asia-south1`, Azure
Central India, or any Indian VPS). A US/EU host will fail with connection errors.

It also needs **headless Chromium** (Playwright), so ~1–2 GB RAM and the Playwright
system dependencies. The `Dockerfile` handles all of that — deploy the container
and you're done.

---

## 1. Where it is deployed today (reference deployment)

| | |
|---|---|
| **Platform** | Fly.io |
| **App name** | `mpqr-pat-bot` |
| **Region** | `bom` (Mumbai, India) |
| **URL** | `https://mpqr-pat-bot.fly.dev` |
| **VM** | `shared-cpu-1x`, **2 GB** RAM, 1 machine, always-on |
| **Runtime** | Node 22 + Playwright Chromium (from the `Dockerfile`) |
| **Auth** | `MPQR_API_KEY` stored as a Fly **secret** (not in the repo) |
| **Health** | `GET /health` (Fly health check every 30s) |

Live endpoints: `POST /api/patta/start`, `POST /api/patta/verify`,
`POST /api/patta/resend`, `GET /api/live/*`, `GET /metrics`, `GET /health`.

---

## 2. Deploy on Fly.io (the current method)

Prerequisites: a Fly.io account, the `flyctl` CLI, and Docker not required
(Fly builds remotely).

```bash
# 1. Log in
fly auth login

# 2. From the project root, create/point the app (fly.toml already targets bom)
fly launch --no-deploy        # first time only; or `fly apps create mpqr-pat-bot`

# 3. Set the API key as a secret (NEVER commit it)
fly secrets set MPQR_API_KEY=<a-strong-random-key>

# 4. Deploy (remote builder; ~5 min for the Playwright image)
fly deploy --remote-only
```

**Deploy strategy note:** `fly.toml` uses `strategy = "bluegreen"` (zero-downtime).
If Mumbai (`bom`) is out of capacity for a new machine, blue-green fails with
`no capacity available in bom`; in that case use an **in-place** restart:

```bash
fly deploy --remote-only --strategy immediate
```

This restarts the existing machine (a few seconds of downtime) without needing a
new machine. Once `bom` has capacity again, blue-green resumes automatically.

**Old volume cleanup (one-time):** the service is stateless — if an old `mpqr_data`
volume exists from a previous architecture, remove it:
`fly volumes list` then `fly volumes destroy <id>`.

---

## 3. Deploy on any other platform (your own)

The service is a standard Docker container — deploy it anywhere with an **Indian
IP** and ~2 GB RAM:

```bash
# Build
docker build -t mpqr-patta-otp .

# Run (map port, pass the API key + region-appropriate env)
docker run -d --name patta-otp -p 3030:3030 \
  -e MPQR_API_KEY=<a-strong-random-key> \
  -e PORT=3030 \
  --restart unless-stopped \
  mpqr-patta-otp
```

- **AWS**: ECS/Fargate or an EC2 in `ap-south-1` (Mumbai). Give the task ≥2 GB.
- **GCP**: Cloud Run (2 GB, min-instances 1) or a GCE VM in `asia-south1`.
- **Azure**: Container Apps / a VM in **Central India**.
- **Any Indian VPS**: `docker run` as above, behind nginx/Caddy for TLS.

Health check path: `GET /health` (expects HTTP 200). Point your platform's
liveness probe there with a generous grace period (~60s — Chromium warms on boot).

---

## 4. Configuration (environment variables)

Only `MPQR_API_KEY` is required; the rest have safe defaults (see `.env.example`).

| Var | Prod value | Purpose |
|---|---|---|
| `MPQR_API_KEY` | *(secret)* | **Required.** The key callers send in `X-API-Key`. |
| `PORT` | `3030` | Listen port. |
| `MPQR_MAX_CONCURRENT_BROWSERS` | `6` | Hard cap on headless browsers (memory guard, ~300 MB each). Raise only with more RAM. |
| `MPQR_WARM_POOL_SIZE` | `3` | Pre-launched browsers for fast OTP send. |
| `MPQR_WARM_FRESH_MS` | `60000` | Re-navigate a warm browser older than this before a send. |
| `MPQR_KEEPALIVE_MS` | `0` | Session keep-alive — **leave 0 (disabled)**; it corrupted live OTP sessions. |
| `MPQR_RSS_CEILING_MB` | `1500` | Memory watchdog ceiling — keep **below** the VM's RAM. |
| `LOG_LEVEL` | `info` | pino log level. |
| `PDF_FRONT_PAGE` | `off` | Keep off — deliver only the patta + FMB (no branding). |

Sizing: each live customer verify pins one Chromium (~150–350 MB). **2 GB** holds
~5 concurrent safely; scale RAM (or add machines) for higher concurrency.

---

## 5. Verify a deployment

```bash
BASE=https://<your-host>            # e.g. https://mpqr-pat-bot.fly.dev
KEY=<your-api-key>

# 1. Health (open) — expect {"ok":true,...,"warmPool":{"depth":3,...}}
curl -s $BASE/health

# 2. Live dropdowns (needs the key) — expect 38 districts with a `tamil` field
curl -s -H "X-API-Key: $KEY" "$BASE/api/live/districts" | head -c 300

# 3. Metrics (needs the key)
curl -s -H "X-API-Key: $KEY" "$BASE/metrics" | head

# 4. Full OTP flow — use the built-in tester at $BASE/dashboard (enter the key),
#    or POST /api/patta/start then /api/patta/verify with a real OTP.
```

A healthy instance shows `warmPool.depth` climbing to `3/3` in `/health` and no
repeated `govt session not alive` lines in the logs (`fly logs -a mpqr-pat-bot`).

---

## 6. Operations

- **Logs:** `fly logs -a mpqr-pat-bot` (structured JSON; mobile/OTP/key are redacted).
- **Metrics:** `GET /metrics` (Prometheus). Watch `mpqr_otp_wasted_total` — it should
  stay flat; a rise means OTPs are being consumed without delivering a PDF.
- **Rate limit:** the government allows **10 OTPs/day/mobile**. Per-customer, so not a
  system cap, but surface `RATE_LIMITED` (429) to the user gracefully.
- **Restart/scale:** the service is stateless — restart or add machines freely. For
  real redundancy, run ≥2 machines (the code already routes `/verify` to the owning
  machine via `fly-replay`); note this doubles cost.
- **Secrets:** rotate `MPQR_API_KEY` with `fly secrets set MPQR_API_KEY=<new>` (triggers
  a redeploy). Never put it in `fly.toml`, `.env` (committed), or the image.

---

## 7. Local development

```bash
cp .env.example .env          # set MPQR_API_KEY
npm install
npx playwright install chromium
npm start                     # → http://localhost:3030/dashboard
```

> Local runs need an **Indian IP / VPN** to reach the government site; without one,
> the boot succeeds and `/health` works, but `/api/live/*` and the OTP flow fail with
> connection errors.
